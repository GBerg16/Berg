
TITLE: 
Roxy - Bootstrap 4 template built by GetTemplates.co

AUTHOR:
DESIGNED & DEVELOPED by GetTemplates.co and FreeHTML5.co

Websites: https://gettemplates.co https://freehtml5.co/


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

OwlCarousel
https://owlcarousel2.github.io/OwlCarousel2/

Isotope
https://isotope.metafizzy.co

Select2
https://select2.org

Stellar
http://markdalgleish.com/projects/stellar.js/

Lightcase
https://cornel.bopp-art.com/lightcase/

Demo Images:
http://unsplash.com

